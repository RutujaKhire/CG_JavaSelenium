package com.Pages;

import static org.junit.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CheckOutPage {
	
	WebDriver driver;
	
	@FindBy(id = "first-name")
	WebElement firstname;
	
	@FindBy(id = "last-name")
	WebElement lastname;
	
	@FindBy(id = "postal-code")
	WebElement zipcode;
	
	@FindBy(id = "continue")
	WebElement contBtn;
	
	@FindBy(xpath = "//*[@id=\"header_container\"]/div[2]/span")
	WebElement checkoutTitle;
	
	public CheckOutPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		PageFactory.initElements(driver, CheckOutPage.class);		
	}

	public void fillDetails(String firstN, String lastN, String zip) {
		// TODO Auto-generated method stub
		firstname.sendKeys(firstN);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		lastname.sendKeys(lastN);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		zipcode.sendKeys(zip);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}

	public void proceedCheckout() {
		// TODO Auto-generated method stub
		contBtn.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void assertTitle() {
		assertTrue(checkoutTitle.isDisplayed());
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}

}
