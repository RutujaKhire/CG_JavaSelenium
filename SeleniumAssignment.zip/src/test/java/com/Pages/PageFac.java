package com.Pages;

import static org.junit.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageFac {
	
	WebDriver driver;

	public PageFac(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		PageFactory.initElements(driver, this);		
	}
	
	//LoginPage
//------------------------------------------------------------------------------------------------------------
	
	@FindBy(id = "user-name")
	WebElement username;
	
	@FindBy(xpath = "//*[@placeholder='Password']")
	WebElement password;
	
	@FindBy(id = "login-button")
	WebElement loginBtn;
	
	@FindBy(xpath = "//*[@id=\"header_container\"]/div[2]/span")
	WebElement productsHeader;
	
	@FindBy(xpath = "//*[@id=\"login_button_container\"]/div/form/div[3]/h3")
	WebElement errorMSG;
	
	public void loadPage() throws InterruptedException{
		driver.get("https://www.saucedemo.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void enterUandP(String userName, String passWord) {
		username.sendKeys(userName);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		password.sendKeys(passWord);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void clickLogin() {
		loginBtn.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void loginSuccessful() {
		if(productsHeader.isDisplayed())
			System.out.println("Login Successful");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void loginUnsuccessful() {
		if(errorMSG.isDisplayed())
			System.out.println("Login Unsuccessful");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void closePage() {
		driver.close();
	}
	
	//InventoryPage
//------------------------------------------------------------------------------------------------------------
	
	@FindBy(xpath = "//*[@id=\"header_container\"]/div[2]/div[2]/span/select")
	WebElement dropdown;
	
	@FindBy(xpath = "//*[@id=\"inventory_container\"]/div/div[1]/div[2]/div[2]/div/text()[2]")
	WebElement price;
	
	@FindBy(id = "add-to-cart-sauce-labs-onesie")
	WebElement OnesieBtn;
	
	@FindBy(id = "add-to-cart-sauce-labs-bike-light")
	WebElement BikeLightBtn;
	
	@FindBy(xpath = "//*[@id=\"shopping_cart_container\"]/a")
	WebElement cartIcon;
	
	@FindBy(xpath = "//*[@id=\"shopping_cart_container\"]/a/span")
	WebElement cartIconNum;
	
	Select sort = new Select(dropdown);
	
	public void sortElements() {
		sort.selectByVisibleText("Price (low to high)");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void assertPrice(){
		assertTrue((price.getText()).contains("7.99"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void addOnesie() {
		OnesieBtn.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void addBikeLight() {
		BikeLightBtn.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void assertCartValue(){
		assertTrue((cartIconNum.getText()).contains("2"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void openCart() {
		cartIcon.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	//CartPage
//------------------------------------------------------------------------------------------------------------
	
	@FindBy(id = "remove-sauce-labs-bike-light")
	WebElement bikeLightBtn;
	
	@FindBy(id = "checkout")
	WebElement checkOutBtn;
	
	public void removeBikeLight() {
		// TODO Auto-generated method stub
		bikeLightBtn.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void clickCheckOut() {
		// TODO Auto-generated method stub
		checkOutBtn.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	//CheckOutPage
//------------------------------------------------------------------------------------------------------------
	
	@FindBy(id = "first-name")
	WebElement firstname;
	
	@FindBy(id = "last-name")
	WebElement lastname;
	
	@FindBy(id = "postal-code")
	WebElement zipcode;
	
	@FindBy(id = "continue")
	WebElement contBtn;
	
	@FindBy(xpath = "//*[@id=\"header_container\"]/div[2]/span")
	WebElement checkoutTitle;
	
	public void assertTitle() {
		assertTrue(checkoutTitle.isDisplayed());
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void fillDetails(String firstN, String lastN, String zip) {
		// TODO Auto-generated method stub
		firstname.sendKeys(firstN);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		lastname.sendKeys(lastN);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		zipcode.sendKeys(zip);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void proceedCheckout() {
		// TODO Auto-generated method stub
		contBtn.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	//CheckOut2Page
//------------------------------------------------------------------------------------------------------------
	
	@FindBy(xpath = "//*[@id=\"header_container\"]/div[2]/span")
	WebElement chkoutHeader;
	
	@FindBy(xpath = "//*[@id=\"checkout_summary_container\"]/div/div[2]/div[7]/text()[2]")
	WebElement total;
	
	@FindBy(id="finish")
	WebElement finishBtn;
	
	public void assertCheckout() {
		assertTrue(chkoutHeader.isDisplayed());
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void assertTotal(){
		assertTrue((total.getText()).contains("7.99"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void finish() {
		finishBtn.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
}
