package com.Pages;

import static org.junit.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class InventoryPage {
	
	WebDriver driver;
	
	@FindBy(xpath = "//*[@id=\"header_container\"]/div[2]/div[2]/span/select")
	WebElement dropdown;
	
	@FindBy(xpath = "//*[@id=\"inventory_container\"]/div/div[1]/div[2]/div[2]/div/text()[2]")
	WebElement price;
	
	@FindBy(id = "add-to-cart-sauce-labs-onesie")
	WebElement OnesieBtn;
	
	@FindBy(id = "add-to-cart-sauce-labs-bike-light")
	WebElement BikeLightBtn;
	
	@FindBy(xpath = "//*[@id=\"shopping_cart_container\"]/a")
	WebElement cartIcon;
	
	@FindBy(xpath = "//*[@id=\"shopping_cart_container\"]/a/span")
	WebElement cartIconNum;
	
	Select sort = new Select(dropdown);
	
	public InventoryPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		PageFactory.initElements(driver, InventoryPage.class);
	}	
	
	public void closePage() {
		driver.close();
	}
	
	public void sortElements() {
		sort.selectByVisibleText("Price (low to high)");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void assertPrice(){
		assertTrue((price.getText()).contains("7.99"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void addOnesie() {
		OnesieBtn.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void addBikeLight() {
		BikeLightBtn.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void assertCartValue(){
		assertTrue((cartIconNum.getText()).contains("2"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void openCart() {
		cartIcon.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
}
