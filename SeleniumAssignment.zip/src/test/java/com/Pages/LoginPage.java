package com.Pages;


import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
	WebDriver driver;
	
	@FindBy(id = "user-name")
	WebElement username; //= driver.findElement(By.id("user-name"));
	
	@FindBy(xpath = "//*[@placeholder='Password']")
	WebElement password; //= driver.findElement(By.id("password"));
	
	@FindBy(id = "login-button")
	WebElement loginBtn; //= driver.findElement(By.id("login-button"));
	
	@FindBy(xpath = "//*[@id=\"header_container\"]/div[2]/span")
	WebElement productsHeader; //= driver.findElement(By.xpath("//*[@id=\\\"header_container\\\"]/div[2]/span"));
	
	@FindBy(xpath = "//*[@id=\"login_button_container\"]/div/form/div[3]/h3")
	WebElement errorMSG; //= driver.findElement(By.xpath("//*[@id=\\\"login_button_container\\\"]/div/form/div[3]/h3/text()"));
	
	public LoginPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		PageFactory.initElements(driver, this);		
	}
	
	public void loadPage() throws InterruptedException{
		driver.get("https://www.saucedemo.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	public void closePage() {
		driver.close();
	}
	
	public void enterUandP(String userName, String passWord) {
		username.sendKeys(userName);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		//System.out.println(driver.findElement(By.xpath("//*[@placeholder='Password']")));
		//driver.findElement(By.xpath("//*[@placeholder='Password']")).sendKeys("Hello");
		password.sendKeys(passWord);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void clickLogin() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		loginBtn.click();
	}
	
	public void loginSuccessful() {
		if(productsHeader.isDisplayed())
			System.out.println("Login Successful");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public void loginUnsuccessful() {
		errorMSG.isDisplayed();
		System.out.println("Login Unsuccessful");
	}
	
	public void enterCredentials() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		username.sendKeys("standard_user");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		password.sendKeys("secret_sauce");
	}

}
