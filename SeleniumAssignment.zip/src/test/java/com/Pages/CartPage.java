package com.Pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CartPage {
	
	WebDriver driver;
	
	@FindBy(id = "remove-sauce-labs-bike-light")
	WebElement bikeLightBtn;
	
	@FindBy(id = "checkout")
	WebElement checkOutBtn;

	public CartPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		PageFactory.initElements(driver, InventoryPage.class);
	}

	public void removeBikeLight() {
		// TODO Auto-generated method stub
		bikeLightBtn.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}

	public void clickCheckOut() {
		// TODO Auto-generated method stub
		checkOutBtn.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
}
