package com.StepDefinitions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.Pages.CartPage;
import com.Pages.CheckOutPage;
import com.Pages.InventoryPage;
import com.Pages.LoginPage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Cart_SD {
	
	WebDriver driver = new ChromeDriver();
	LoginPage loginPageObj = new LoginPage(driver);
	InventoryPage inventoryPageObj = new InventoryPage(driver);
	CartPage cartPageObj = new CartPage(driver);
	CheckOutPage checkoutPageObj = new CheckOutPage(driver);
	
	@Given("Cart Page is open")
	public void cart_page_is_open() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		loginPageObj.loadPage();
		loginPageObj.clickLogin();
		loginPageObj.loginSuccessful();
		inventoryPageObj.openCart();
	}

	@And("User removes Bike Light from cart")
	public void user_removes_bike_light_from_cart() {
	    // Write code here that turns the phrase above into concrete actions
		cartPageObj.removeBikeLight();
	    
	}

	@And("User checks out")
	public void user_checks_out() {
	    // Write code here that turns the phrase above into concrete actions
		cartPageObj.clickCheckOut();
	}

	@Then("Checkout Page is Loaded")
	public void checkout_page_is_loaded() {
	    // Write code here that turns the phrase above into concrete actions
		checkoutPageObj.assertTitle();
	}
}
