package com.StepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.Pages.LoginPage;

//import com.Pages.PageFac;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Login_SD {

	WebDriver driver = new ChromeDriver();
	LoginPage loginPageObj = new LoginPage(driver);
	//LoginPage PFobj = new LoginPage(driver);

	@Given("Website is open")
	public void website_is_open() throws InterruptedException{
		loginPageObj.loadPage();
	}

	@And("User enters valid username {string} and password {string}")
	public void user_enters_valid_username_and_password(String userName, String passWord) {
		// Write code here that turns the phrase above into concrete actions
		loginPageObj.enterUandP(userName, passWord);
	}

	@And("User clicks on Login button")
	public void user_clicks_on_login_button() {
		// Write code here that turns the phrase above into concrete actions
		loginPageObj.clickLogin();
	}

	@Then("Inventory page is loaded")
	public void inventory_page_is_loaded() {
		// Write code here that turns the phrase above into concrete actions
		loginPageObj.loginSuccessful();
		//loginPageObj.closePage();
	}
	
	@And("User enters invalid username {string} and password {string}")
	public void user_enters_invalid_username_and_password(String userName, String passWord) {
		// Write code here that turns the phrase above into concrete actions
		loginPageObj.enterUandP(userName, passWord);
	}

	@Then("Error message is displayed")
	public void error_message_is_displayed() {
		// Write code here that turns the phrase above into concrete actions
		loginPageObj.loginUnsuccessful();
		loginPageObj.closePage();
	}

}
