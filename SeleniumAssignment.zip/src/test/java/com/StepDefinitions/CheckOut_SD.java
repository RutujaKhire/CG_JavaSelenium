package com.StepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.Pages.CartPage;
import com.Pages.CheckOutPage;
import com.Pages.InventoryPage;
import com.Pages.LoginPage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class CheckOut_SD {
	
	WebDriver driver = new ChromeDriver();
	LoginPage loginPageObj = new LoginPage(driver);
	InventoryPage inventoryPageObj = new InventoryPage(driver);
	CartPage cartPageObj = new CartPage(driver);
	CheckOutPage checkoutPageObj = new CheckOutPage(driver);
	
	@Given("User is on CheckOut Page")
	public void user_is_on_check_out_page() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		loginPageObj.loadPage();
		loginPageObj.clickLogin();
		loginPageObj.loginSuccessful();
		inventoryPageObj.openCart();
		cartPageObj.clickCheckOut();
	}

	@And("User enters details {string} {string} {string}")
	public void user_enters_details(String firstN, String lastN, String zip) {
	    // Write code here that turns the phrase above into concrete actions
		checkoutPageObj.fillDetails(firstN, lastN, zip);
	}

	@And("User clicks on Continue")
	public void user_clicks_on_continue() {
	    // Write code here that turns the phrase above into concrete actions
		checkoutPageObj.proceedCheckout();
	}

	@Then("CheckOut Overview is displayed")
	public void check_out_overview_is_displayed() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Rutuja");
	}


}
