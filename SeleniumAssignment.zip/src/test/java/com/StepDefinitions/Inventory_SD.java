package com.StepDefinitions;
import com.Pages.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Inventory_SD {
	
	WebDriver driver = new ChromeDriver();
	
	LoginPage loginPageObj = new LoginPage(driver);
	InventoryPage inventoryPageObj = new InventoryPage(driver);
	//LoginPage loginPageObj;
	//InventoryPage PFobj;//inventoryPageObj;
	
	//PageFac PFobj;
	
	@Given("Inventory Page is open")
	public void inventory_page_is_open() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		//loginPageObj2.loadPage();
		loginPageObj.enterUandP("standard_user", "secret_sauce");
		loginPageObj.clickLogin();
		loginPageObj.loginSuccessful();
	}
	
	@And("User enters valid credentials")
	public void user_enters_valid_credentials() {
	    // Write code here that turns the phrase above into concrete actions
		loginPageObj.enterUandP("standard_user", "secret_sauce");
	}
	
	@Then("User is redirected to inventory page")
	public void user_is_redirected_to_inventory_page() {
	    // Write code here that turns the phrase above into concrete actions
		loginPageObj.loginSuccessful();
	}
	
	@Given("User clicks on login button")
	public void user_clicks_on_login_button() {
	    // Write code here that turns the phrase above into concrete actions
		loginPageObj.clickLogin();
	}

	@Given("User selects price-low to high from sort dropdown")
	public void user_selects_price_low_to_high_from_sort_dropdown() {
	    // Write code here that turns the phrase above into concrete actions
		inventoryPageObj.sortElements();
	}

	@Then("The first product costs eight dollars")
	public void the_first_product_costs_eight_dollars() {
	    // Write code here that turns the phrase above into concrete actions
		inventoryPageObj.assertPrice();
	}

	@Given("User clicks on add to cart button of onesie")
	public void user_clicks_on_add_to_cart_button_of_onesie() {
	    // Write code here that turns the phrase above into concrete actions
		inventoryPageObj.addOnesie();
	}

	@And("User clicks on add to cart button of bikelight")
	public void user_clicks_on_add_to_cart_button_of_backpack() {
	    // Write code here that turns the phrase above into concrete actions
		inventoryPageObj.addBikeLight();
	}

	@Then("The cart icon will have two displayed")
	public void the_cart_icon_will_have_two_displayed() {
	    // Write code here that turns the phrase above into concrete actions
		inventoryPageObj.assertCartValue();
	}
}
