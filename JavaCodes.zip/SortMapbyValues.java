package JavaTask;


import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class SortMapbyValues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer, String> hmap = new HashMap<Integer, String>();
		hmap.put(1, "XYZ");
		hmap.put(2, "LMN");
		hmap.put(3, "ABC");
		hmap.put(4, "PQR");
		
		boolean order = true;
		
		List<Map.Entry<Integer, String>> tempList = new LinkedList<Map.Entry<Integer, String>>(hmap.entrySet());
		
		Collections.sort(
				tempList, 
				new Comparator<Entry<Integer, String>>()
				{
					public int compare(Entry<Integer, String> o1, Entry<Integer, String> o2)
					{
						if(order)
							return(o1.getValue().compareTo(o2.getValue()));
						else
							return(o2.getValue().compareTo(o1.getValue()));
					}
				}
			);
		
		HashMap<Integer, String> temp = new LinkedHashMap<Integer, String>();
		
		for(Entry<Integer, String> e: tempList)
			temp.put(e.getKey(), e.getValue());
		
		for (Entry<Integer, String> e : temp.entrySet()) 
			System.out.println("Key = " + e.getKey() + ", Value = " + e.getValue());
	}
}