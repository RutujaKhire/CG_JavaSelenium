package JavaTask;

import java.util.Scanner;

public class FrequencyOfChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter string:");
		String str = sc.nextLine();
		
		System.out.println("Enter char to find frequency:");
		char ch = sc.next().charAt(0);
		int freq = 0;
		
		for(int i = 0; i < str.length(); i++)
		{
			if(str.charAt(i) == ch)
				freq++;
		}
		
		System.out.println("Frequency of char " + ch + " in the string is " + freq);
		
		sc.close();
	}

}
