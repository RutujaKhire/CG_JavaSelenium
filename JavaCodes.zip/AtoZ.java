package JavaTask;

public class AtoZ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(char c = 'A'; c <= 'Z'; c++) {
			System.out.print(c + " ");
		}
	}

}
