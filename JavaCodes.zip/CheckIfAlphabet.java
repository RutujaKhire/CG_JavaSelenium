package JavaTask;

import java.util.Scanner;

public class CheckIfAlphabet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter Character: ");
		Scanner sc = new Scanner(System.in);
		char ch = sc.next().charAt(0);
		
		if((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')) {
			System.out.println("Char " + ch + " is an alphabet");
		}
		else {
			System.out.println("Char " + ch + " is not an alphabet");
		}	
		
		sc.close();
	}
}
