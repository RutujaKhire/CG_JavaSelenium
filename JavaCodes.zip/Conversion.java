package JavaTask;

import java.util.Arrays;

public class Conversion {
	
	public void ChartoString(char c) {
		String str = Character.toString(c);
		System.out.println("The string is: " + str);
	}
	
	public void StringtoChar(String s) {
		char chars[] = s.toCharArray();
		System.out.println(Arrays.toString(chars));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Conversion obj = new Conversion();
		char ch = 'R';
		obj.ChartoString(ch);
		String str = "Rutuja";
		obj.StringtoChar(str);
	}
}
