package JavaTask;

interface Library{
	public void printLibrary();
}

interface Classrooms{
	public void printClassrooms();
}

interface Auditorium{
	public void printAuditorium();
}
public class ImplementMultipleInterfaces implements Library, Classrooms, Auditorium {
	
	public void printLibrary() {
		System.out.println("The college has a library");
	}
	public void printClassrooms() {
		System.out.println("The college has multiple classrooms");
	}
	public void printAuditorium() {
		System.out.println("The college has an auditorium");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ImplementMultipleInterfaces obj =  new ImplementMultipleInterfaces();
		obj.printLibrary();
		obj.printClassrooms();
		obj.printAuditorium();
	}
}
