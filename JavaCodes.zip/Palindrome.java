package JavaTask;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the string to check if Palindrome or not: ");
		Scanner sc = new Scanner(System.in);
		String input = sc.next();
		String rev = "";
		
		for(int i = input.length()-1; i >= 0; i--)
		{
			rev = rev + input.charAt(i);
		}
		if(input.equals(rev))
			System.out.println("Is a palindrome");
		else
			System.out.println("Not a palindrome");		
		
		sc.close();
	}

}
