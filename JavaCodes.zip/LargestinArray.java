package JavaTask;

import java.util.Scanner;

public class LargestinArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter number of elements of array:");
		int size = sc.nextInt();
		
		int arr[] = new int[size];
		System.out.println("Enter elements:");
		for(int i = 0; i < size; i++) {
			arr[i] = sc.nextInt();
		}
		
		int largest = 0;
		
		for(int i: arr)
		{
			if(i > largest) {
				largest = i;
			}
		}
		System.out.println("The largest element in the array is: " + largest);
		
		sc.close();
	}

}
