package JavaTask;

import java.util.Scanner;

public class ArrayContains {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter number of elements of array:");
		int size = sc.nextInt();
		
		int arr[] = new int[size];
		System.out.println("Enter elements:");
		for(int i = 0; i < size; i++) {
			arr[i] = sc.nextInt();
		}
		
		System.out.println("Enter number to check if present in array: ");
		int num = sc.nextInt();
		boolean flag = false;
		
		for(int i = 0; i < size; i++) {
			if(arr[i] == num) {
				flag = true;
				break;
			}
		}
		if(flag)
			System.out.println("Element is present in array");
		else
			System.out.println("Element is not present in array");
		
		sc.close();
		
	}

}
