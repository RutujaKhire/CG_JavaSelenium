package JavaTask;

abstract class AbstractClass {
	abstract void printSomething();
}

public class AbstractClassImplement extends AbstractClass{
	
	void printSomething() {
		// TODO Auto-generated method stub
		System.out.println("Implementing abstract method from abstract class");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractClass obj = new AbstractClassImplement();
		obj.printSomething();
	}

	
}
