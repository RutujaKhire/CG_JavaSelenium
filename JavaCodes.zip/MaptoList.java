package JavaTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MaptoList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		map.put(1, "ABC");
		map.put(2, "LMN");
		map.put(3, "XYZ");
		
		List<Integer> keyList = new ArrayList<>(map.keySet());
		List<String> valueList = new ArrayList<>(map.values());
		
		System.out.println("The keys in the map are: " + keyList);
		System.out.println("The values in the map are: " + valueList);
		
	}

}
