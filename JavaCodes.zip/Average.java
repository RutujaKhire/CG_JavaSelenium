package JavaTask;

import java.util.Scanner;

public class Average {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter number of elements:");
		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
		int sum = 0;
		
		int arr[] = new int[size];
		System.out.println("Enter elements:");
		for(int i = 0; i < size; i++) {
			arr[i] = sc.nextInt();
		}
		
		for(int n: arr) {
			sum += n;
		}
		
		System.out.println("The average os the elements is: " + sum/size);
		sc.close();
	}

}
