package JavaTask;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter number to check if prime: ");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		boolean flag = true;
		
		if(num == 2) {
			System.out.println("Is a prime number");
		}
		else if(num%2 == 0) {
			System.out.println("Not a prime number");
		}
		else {
			for(int i = 2; i < num/2; i++) {
				if(num%i == 0) {
					flag = false;
					break;
				}
			}
			if(flag)
				System.out.println("Is a prime number");
			else
				System.out.println("Not a prime number");
		}
		
		sc.close();
	}

}
