package JavaTask;

class Method {
	public void printMethod(){
		System.out.println("Hi, this is from Parent Class");
	}
}

public class MethodOverriding extends Method {
	
	public void printMethod(){
		super.printMethod();
		System.out.println("Hi, this is from Child Class");
	} 
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodOverriding obj = new MethodOverriding();
		obj.printMethod();
	}

}
