package JavaTask;

import java.util.Scanner;

public class ConcatArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of elements of array1:");
		int size1 = sc.nextInt();
		
		int arr1[] = new int[size1];
		System.out.println("Enter elements:");
		for(int i = 0; i < size1; i++) {
			arr1[i] = sc.nextInt();
		}
		
		System.out.println("Enter number of elements of array2:");
		int size2 = sc.nextInt();
		
		int arr2[] = new int[size2];
		System.out.println("Enter elements:");
		for(int i = 0; i < size2; i++) {
			arr2[i] = sc.nextInt();
		}
		
		int size3 = size1+size2;
		int arr3[] = new int[size3];
		
		for(int i = 0; i < size1; i++)
		{
			arr3[i] = arr1[i]; 
		}
		for(int i = 0; i < size2; i++)
		{
			arr3[size1 + i] = arr2[i]; 
		}
		System.out.println("Concatenated array is:");
		for(int e: arr3)
			System.out.print(e + " ");
		
		sc.close();
	}

}
