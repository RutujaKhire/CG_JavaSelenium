package JavaTask;

interface printSomething{
	public void printFunction();
}

public class InterfaceImplement implements printSomething{
	
	public void printFunction(){
		System.out.println("This class is implementing the interface");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfaceImplement obj = new InterfaceImplement();
		obj.printFunction();
	}

}
