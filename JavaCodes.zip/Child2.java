package JavaTask;

class Parent2 {
	public void printParent(){
		System.out.println("Hi, this is from Parent Class");
	}
}

public class Child2 extends Parent2 {
	public void printChild(){
		System.out.println("Hi, this is from Child Class");
	}
	
	public static void main(String[] args) {
		Parent2 obj = new Child2();
		obj.printParent();
		((Child2) obj).printChild();
	}
}
