package JavaTask;

public class AddMatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int matrix1[][] = {
				{1, 1},
				{2, 2}
		};
		int matrix2[][] = {
				{1, 1},
				{2, 2}
		};
		int sum[][] = new int[2][2];
		
		for(int r = 0; r < 2; r++) {
			for(int c = 0; c < 2; c++) {
				sum[r][c] = matrix1[r][c] + matrix2[r][c];
			}
		}
		
		System.out.println("The sum of the matrices is: ");
		for(int r = 0; r < 2; r++) {
			for(int c = 0; c < 2; c++) {
				System.out.print(sum[r][c] + " ");
			}
			System.out.println();
		}
	}

}
