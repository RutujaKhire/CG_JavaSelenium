package JavaTask;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter limit of the series: ");
		Scanner sc = new Scanner(System.in);
		int limit = sc.nextInt();
		
		int n1 = 0;
		int n2 = 1;
		int next;
		
		System.out.println(n1);
		System.out.println(n2);
		
		for(int i =1; i <= limit-2; i++)
		{
			next = n1 + n2;
			System.out.println(next);
			n1 = n2;
			n2 = next;
		}
		
		sc.close();
	}

}
