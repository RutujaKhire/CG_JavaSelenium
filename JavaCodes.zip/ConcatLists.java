package JavaTask;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ConcatLists {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		List<Integer> list1 = new ArrayList<Integer>();
		System.out.println("Enter number of elements in list1:");
		int size1 = sc.nextInt();
		
		for(int i = 0; i < size1; i++) {
			list1.add(sc.nextInt());
		}
		List<Integer> list2 = new ArrayList<Integer>();
		System.out.println("Enter number of elements in list2:");
		int size2 = sc.nextInt();
		
		for(int i = 0; i < size2; i++) {
			list1.add(sc.nextInt());
		}
		
		List<Integer> concat = new ArrayList<Integer>();
		concat.addAll(list1);
		concat.addAll(list2);
		
		System.out.println("The concatenatedl list is: " + concat);		
		
		sc.close();
	}

}
