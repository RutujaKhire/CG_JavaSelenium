package JavaTask;


public class SwapNumbers {

	public void swap(int n1, int n2) {
		// TODO Auto-generated constructor stub
		System.out.println("The original numbers are: " + "n1= " + n1 + " n2= "+ n2);
		int temp;
		temp = n1;
		n1 = n2;
		n2 = temp;
		
		System.out.println("The swapped numbers are: " + "n1= " + n1 + " n2= "+ n2);
	}

	public void swapWOTemp(int n1, int n2) {
		// TODO Auto-generated method stub
		System.out.println("The original numbers are: " + "n1= " + n1 + " n2= "+ n2);
		n1 = n1 + n2;
		n2 = n1 - n2;
		n1 = n1 - n2;
		
		System.out.println("The swapped numbers w/o temp are: " + "n1= " + n1 + " n2= "+ n2);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwapNumbers obj = new SwapNumbers();
		obj.swap(36, 45);
		obj.swapWOTemp(12, 89);
	}

}
