package JavaTask;

class Parent1 {
	public void printParent(){
		System.out.println("Hi, this is from Parent Class");
	}
}
class Child1 extends Parent1 {
	public void printChild(){
		System.out.println("Hi, this is from Child Class");
	}
	
	public static void main(String[] args) {
		Child1 obj = new Child1();
		obj.printParent();
		obj.printChild();
	}
}