package JavaTask;

import java.util.ArrayList;
import java.util.List;

public class Conversion2 {

		public void ArraytoList(int arr[]) {
			List<Integer> list = new ArrayList<Integer>();
			for(int i: arr)
			{
				list.add(i);
			}
			System.out.println("The converted list is: " + list);
		}
		
		public void ListtoArray(List<Integer> list) {
			Object[] arr = list.toArray();
			System.out.print("The converted array is: ");
			for(Object i: arr)
				System.out.print(i + " ");
			
		}

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Conversion2 obj = new Conversion2();
			int inputArray[] = {1, 2 , 3, 4, 5};
			obj.ArraytoList(inputArray);
			List<Integer> inputList = new ArrayList<Integer>();
			inputList.add(6);
			inputList.add(7);
			inputList.add(8);
			inputList.add(9);
			inputList.add(10);
			obj.ListtoArray(inputList);
		}
}

